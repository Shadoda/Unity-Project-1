const config = require('../config.js');
const crypto = require('crypto');
const CardModel = require('../cards/cards.model');

const CardTool = {};

CardTool.getPackCards = async(pack) =>
{
    var pack_cards = await CardModel.getByPack(pack.tid);
    var cards = [];
    for(var i=0; i<pack.cards; i++)
    {
        var rarity = CardTool.getRandomRarity(pack, i==0);
        var rarity_cards = CardTool.getCardArray(pack_cards, rarity);
        var card = CardTool.getRandomCard(rarity_cards);
        if(card)
        {
            cards.push(card);
        }
    }
    return cards;
};

CardTool.getRandomRarity = (pack, is_first) =>
{
    var rarities = is_first ? pack.rarities_1st : pack.rarities;
    if(!rarities || rarities.length == 0)
        rarities = [40,30,20,10]; //Default value, 40% common, 30% uncommon...

    var total = 0;
    for(var val of rarities) {
        total += val;
    }

    var rvalue = Math.floor(Math.random()*total);

    for(var i=0; i<rarities.length; i++)
    {
        var prob = rarities[i];
        if(rvalue < prob)
        {
            return (i+1); //Rarity start at 1, not 0
        }
        rvalue -= prob;
    }
    return 1;
};

CardTool.getCardArray = (all_cards, rarity) =>
{
    var valid_cards = [];
    for(var i=0; i<all_cards.length; i++)
    {
        var card = all_cards[i];
        if(card.rarity == rarity)
            valid_cards.push(card);
    }
    return valid_cards;
}

CardTool.getRandomCard = (all_cards) =>
{
    if(all_cards.length > 0)
    {
        var card = all_cards[Math.floor(Math.random()*all_cards.length)];
        var cardQ = {tid: card.tid, quantity: 1};
        return cardQ;
    }
    return null;
};

module.exports = CardTool;